package com.sachin.nseanalyzer;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

public class MainActivity extends Activity {
    private static final int FILE_PICKER = 42;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private android.content.SharedPreferences prefs;
    private FrameLayout root;
    private GrowwChartView chartView;
    private java.util.concurrent.ScheduledExecutorService growwExec;
    private java.util.concurrent.ScheduledExecutorService clockExec;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("auth", MODE_PRIVATE);
        if (!prefs.getBoolean("setup_done", false)) showSetup(); else showLogin();
    }

    private TextView title(String t) {
        TextView v = new TextView(this); v.setText(t); v.setTextSize(24); v.setTextColor(Color.WHITE); v.setGravity(Gravity.CENTER); v.setPadding(0,20,0,20); return v;
    }
    private EditText edit(String hint, boolean password) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextColor(Color.WHITE); e.setHintTextColor(0xff9fb1c3); e.setSingleLine(true); e.setPadding(18,12,18,12);
        e.setBackgroundColor(0xff15202b); if(password) e.setInputType(0x81); return e;
    }
    private Button btn(String text) { Button b=new Button(this); b.setText(text); return b; }

    private LinearLayout authBox(String heading) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(28,24,28,24); box.setBackgroundColor(0xff0b131c);
        TextView h=title(heading); box.addView(h); return box;
    }

    private void showSetup() {
        LinearLayout box=authBox("NSE Analyzer • Create Login");
        TextView info=new TextView(this); info.setText("Create your app ID and password. These are stored only on this device. The analyzer itself remains the V10 engine."); info.setTextColor(0xffc5d3df); info.setPadding(0,0,0,18); box.addView(info);
        EditText id=edit("Create ID",false), pw=edit("Create Password",true), pw2=edit("Confirm Password",true); box.addView(id); box.addView(pw); box.addView(pw2);
        Button save=btn("Create & Open App"); box.addView(save);
        save.setOnClickListener(v->{ String u=id.getText().toString().trim(), p=pw.getText().toString(), c=pw2.getText().toString();
            if(u.length()<3 || p.length()<6){toast("ID 3+ characters and password 6+ characters required");return;}
            if(!p.equals(c)){toast("Passwords do not match");return;}
            prefs.edit().putString("user",u).putString("pass",sha256(p)).putBoolean("setup_done",true).apply(); showAnalyzer(); });
        setContentView(box);
    }

    private void showLogin() {
        LinearLayout box=authBox("NSE Analyzer • Login");
        TextView info=new TextView(this); info.setText("Enter your app ID and password to open the analyzer."); info.setTextColor(0xffc5d3df); info.setPadding(0,0,0,18); box.addView(info);
        EditText id=edit("ID",false), pw=edit("Password",true); box.addView(id); box.addView(pw);
        Button login=btn("Login"); box.addView(login);
        TextView reset=new TextView(this); reset.setText("Forgot password? Clear app data to create a new local login."); reset.setTextColor(0xff8fa3b8); reset.setPadding(0,18,0,0); box.addView(reset);
        login.setOnClickListener(v->{ if(id.getText().toString().equals(prefs.getString("user","")) && sha256(pw.getText().toString()).equals(prefs.getString("pass",""))) showAnalyzer(); else toast("Wrong ID or password"); });
        setContentView(box);
    }

    private void showAnalyzer() {
        root=new FrameLayout(this); setContentView(root);
        webView=new WebView(this); root.addView(webView,new FrameLayout.LayoutParams(-1,-1));
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false); s.setMediaPlaybackRequiresUserGesture(false); s.setDefaultTextEncodingName("UTF-8");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){ if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=callback; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/plain","application/csv","application/vnd.ms-excel"}); try{startActivityForResult(i,FILE_PICKER);return true;}catch(Exception e){fileCallback=null;return false;} }});
        webView.loadUrl("file:///android_asset/index.html");
        startNetworkClock();

        Button groww=btn("Groww Live"); groww.setTextSize(12); groww.setAlpha(.96f); FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(100),dp(52),Gravity.BOTTOM|Gravity.START); gp.setMargins(dp(14),0,0,dp(18)); root.addView(groww,gp); groww.setOnClickListener(v->showGroww());

        Button bot=btn("AI Bot"); bot.setTextSize(12); bot.setAlpha(.96f); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(86),dp(52),Gravity.BOTTOM|Gravity.END); bp.setMargins(0,0,dp(14),dp(18)); root.addView(bot,bp);
        bot.setOnClickListener(v->showBot());
    }


    private void showGroww(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,8,18,4);
        TextView note=new TextView(this); note.setText("Groww live market-data connector. Enter your Groww Access Token (never share it in chat). The token is stored only on this device. Live option-chain snapshots are converted for the existing V10 analyzer; snapshot-to-snapshot ΔOI and premium change are calculated locally."); note.setTextColor(0xff405060); box.addView(note);
        EditText token=edit("Groww Access Token",false); token.setTextColor(0xff202020); token.setHintTextColor(0xff607080); box.addView(token);
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        EditText underlying=edit("NIFTY / BANKNIFTY / SENSEX",false); underlying.setText("NIFTY"); underlying.setTextColor(0xff202020); underlying.setHintTextColor(0xff607080); row.addView(underlying,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
        EditText expiry=edit("YYYY-MM-DD",false); expiry.setText(""); expiry.setTextColor(0xff202020); expiry.setHintTextColor(0xff607080); row.addView(expiry,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1)); box.addView(row);
        TextView chartTitle=new TextView(this); chartTitle.setText("LIVE UNDERLYING • 3-second snapshots"); chartTitle.setTextColor(0xff3dd7d1); chartTitle.setTextSize(12); chartTitle.setTypeface(null,android.graphics.Typeface.BOLD); chartTitle.setPadding(0,10,0,6); box.addView(chartTitle); chartView=new GrowwChartView(this); box.addView(chartView,new LinearLayout.LayoutParams(-1,dp(210)));
        TextView status=new TextView(this); status.setTextColor(0xff202020); status.setPadding(0,8,0,8); box.addView(status);
        Button once=btn("Fetch Groww Option Chain + Update Chart"); box.addView(once);
        Button start=btn("Start Live Chart (3 sec)"); box.addView(start);
        Button stop=btn("Stop Live Chart"); box.addView(stop);
        Button load=btn("Load Latest Groww Chain into V10 Analyzer"); box.addView(load);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("Groww Live Data").setView(box).setNegativeButton("Close",(di,w)->stopGroww()).create();
        String saved=prefs.getString("groww_token",""); if(!saved.isEmpty())token.setText(saved);
        once.setOnClickListener(v->{String k=token.getText().toString().trim(), u=underlying.getText().toString().trim().toUpperCase(), e=expiry.getText().toString().trim(); if(k.isEmpty()||u.isEmpty()||e.isEmpty()){status.setText("Enter Access Token, underlying and expiry date.");return;} prefs.edit().putString("groww_token",k).apply(); fetchGroww(k,u,e,status,false);});
        start.setOnClickListener(v->{String k=token.getText().toString().trim(), u=underlying.getText().toString().trim().toUpperCase(), e=expiry.getText().toString().trim(); if(k.isEmpty()||u.isEmpty()||e.isEmpty()){status.setText("Enter Access Token, underlying and expiry date.");return;} prefs.edit().putString("groww_token",k).apply(); startGroww(k,u,e,status);});
        stop.setOnClickListener(v->stopGroww());
        load.setOnClickListener(v->{if(lastGrowwCsv==null){status.setText("Fetch the Groww chain first.");return;} webView.evaluateJavascript("(function(){var p=document.getElementById('paste'); if(p){p.value="+JSONObject.quote(lastGrowwCsv)+"; var b=document.getElementById('addPaste'); if(b)b.click(); return 'loaded';} return 'paste-box-not-found';})()",x->status.setText("Groww snapshot sent to V10 analyzer: "+x));});
        d.setOnDismissListener(x->stopGroww()); d.show();
    }
    private String lastGrowwCsv; private String lastGrowwKey;
    private void startGroww(String k,String u,String e,TextView status){stopGroww(); growwExec=java.util.concurrent.Executors.newSingleThreadScheduledExecutor(); growwExec.scheduleAtFixedRate(()->fetchGroww(k,u,e,status,true),0,3,java.util.concurrent.TimeUnit.SECONDS);}
    private void stopGroww(){if(growwExec!=null){growwExec.shutdownNow();growwExec=null;}}
    private void fetchGroww(String token,String underlying,String expiry,TextView status,boolean chartOnly){new Thread(()->{try{String exchange=(underlying.equals("SENSEX")||underlying.equals("BANKEX"))?"BSE":"NSE"; URL url=new URL("https://api.groww.in/v1/option-chain/exchange/"+exchange+"/underlying/"+URLEncoder.encode(underlying,"UTF-8")+"?expiry_date="+URLEncoder.encode(expiry,"UTF-8")); HttpURLConnection c=(HttpURLConnection)url.openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("X-API-VERSION","1.0"); int code=c.getResponseCode(); String body=read(code>=200&&code<300?c.getInputStream():c.getErrorStream()); if(code<200||code>=300)throw new Exception("Groww API "+code+": "+body); JSONObject root=new JSONObject(body); JSONObject pay=root.getJSONObject("payload"); double spot=pay.optDouble("underlying_ltp",Double.NaN); chartView.addPoint(spot); lastGrowwCsv=toNseCsv(pay,underlying,expiry); lastGrowwKey=underlying+"|"+expiry; runOnUiThread(()->status.setText("LIVE Groww • "+underlying+" • Spot ₹"+spot+" • snapshot updated "+new java.text.SimpleDateFormat("HH:mm:ss",java.util.Locale.ENGLISH).format(new java.util.Date()))); }catch(Exception ex){runOnUiThread(()->status.setText("Groww error: "+ex.getMessage()));}}).start();}
    private String toNseCsv(JSONObject pay,String underlying,String expiry)throws Exception{StringBuilder out=new StringBuilder("CALLS,,PUTS\n,OI,CHNG IN OI,VOLUME,IV,LTP,CHNG,BID QTY,BID,ASK,ASK QTY,STRIKE,BID QTY,BID,ASK,ASK QTY,CHNG,LTP,IV,VOLUME,CHNG IN OI,OI,\n"); JSONObject strikes=pay.getJSONObject("strikes"); String prev=prefs.getString("groww_prev_"+underlying+"_"+expiry,""); JSONObject prevObj=prev.isEmpty()?new JSONObject():new JSONObject(prev); JSONObject now=new JSONObject(); Iterator<String> it=strikes.keys(); while(it.hasNext()){String sk=it.next(); JSONObject z=strikes.getJSONObject(sk); JSONObject ce=z.optJSONObject("CE"), pe=z.optJSONObject("PE"); double strike=Double.parseDouble(sk); double ceL=ce==null?Double.NaN:ce.optDouble("ltp",Double.NaN), peL=pe==null?Double.NaN:pe.optDouble("ltp",Double.NaN); double ceOi=ce==null?Double.NaN:ce.optDouble("open_interest",Double.NaN), peOi=pe==null?Double.NaN:pe.optDouble("open_interest",Double.NaN); double pCeL=prevObj.optJSONObject(sk)==null?Double.NaN:prevObj.optJSONObject(sk).optDouble("ceL",Double.NaN), pPeL=prevObj.optJSONObject(sk)==null?Double.NaN:prevObj.optJSONObject(sk).optDouble("peL",Double.NaN), pCeOi=prevObj.optJSONObject(sk)==null?Double.NaN:prevObj.optJSONObject(sk).optDouble("ceOi",Double.NaN), pPeOi=prevObj.optJSONObject(sk)==null?Double.NaN:prevObj.optJSONObject(sk).optDouble("peOi",Double.NaN); double ceVol=ce==null?0:ce.optDouble("volume",0), peVol=pe==null?0:pe.optDouble("volume",0); double ceIv=ce==null?Double.NaN:ce.optJSONObject("greeks")==null?Double.NaN:ce.optJSONObject("greeks").optDouble("iv",Double.NaN), peIv=pe==null?Double.NaN:pe.optJSONObject("greeks")==null?Double.NaN:pe.optJSONObject("greeks").optDouble("iv",Double.NaN); double ceD=finiteDiff(ceL,pCeL), peD=finiteDiff(peL,pPeL), ceOiD=finiteDiff(ceOi,pCeOi), peOiD=finiteDiff(peOi,pPeOi); out.append(",").append(num(ceOi)).append(',').append(num(ceOiD)).append(',').append(num(ceVol)).append(',').append(num(ceIv)).append(',').append(num(ceL)).append(',').append(num(ceD)).append(",,,,").append(num(strike)).append(',').append("").append(',').append("").append(',').append("").append(',').append("").append(',').append(num(peD)).append(',').append(num(peL)).append(',').append(num(peIv)).append(',').append(num(peVol)).append(',').append(num(peOiD)).append(',').append(num(peOi)).append(",\n"); JSONObject n=new JSONObject();n.put("ceL",ceL);n.put("peL",peL);n.put("ceOi",ceOi);n.put("peOi",peOi);now.put(sk,n); } prefs.edit().putString("groww_prev_"+underlying+"_"+expiry,now.toString()).apply(); return out.toString();}
    private double finiteDiff(double a,double b){return Double.isFinite(a)&&Double.isFinite(b)?a-b:0;} private String num(double x){return Double.isFinite(x)?String.valueOf(x):"";}

    private static class GrowwChartView extends View{
        Paint p=new Paint(1); Path path=new Path();
        ArrayList<Float> vals=new ArrayList<>(); ArrayList<Long> times=new ArrayList<>();
        public GrowwChartView(Context c){super(c);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);}
        synchronized void addPoint(double v){
            if(Double.isFinite(v)){
                vals.add((float)v); times.add(System.currentTimeMillis());
                if(vals.size()>180){vals.remove(0);times.remove(0);}
                postInvalidate();
            }
        }
        synchronized void clear(){vals.clear();times.clear();postInvalidate();}
        protected synchronized void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(0xff08121b);
            int w=getWidth(),h=getHeight(), left=74,right=16,top=18,bottom=34;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0xff1d3344);
            for(int i=0;i<4;i++){float y=top+(h-top-bottom)*i/3f;c.drawLine(left,y,w-right,y,p);}
            if(vals.size()<2){
                p.setStyle(Paint.Style.FILL);p.setTextSize(18);p.setColor(0xff8aa0b5);
                p.setTextSize(15); c.drawText("Groww live price chart",18,48,p); p.setTextSize(11); c.drawText("Waiting for live snapshot…",18,70,p);return;
            }
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;for(float v:vals){min=Math.min(min,v);max=Math.max(max,v);}
            if(max==min){max=min+1;}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xff38d5a0);path.reset();
            for(int i=0;i<vals.size();i++){float x=left+(w-left-right)*i/(float)(vals.size()-1), y=top+(h-top-bottom)*(max-vals.get(i))/(max-min);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);
            p.setStyle(Paint.Style.FILL);p.setTextSize(12);p.setColor(0xff9fb3c5);
            c.drawText(String.format(Locale.ENGLISH,"₹ %.2f",max),8,top+5,p);
            c.drawText(String.format(Locale.ENGLISH,"₹ %.2f",min),8,h-bottom,p);
            float lastY=top+(h-top-bottom)*(max-vals.get(vals.size()-1))/(max-min);
            p.setColor(0xffe9f4ff);p.setTextSize(18);c.drawText(String.format(Locale.ENGLISH,"₹ %.2f",vals.get(vals.size()-1)),left,Math.max(18,lastY-8),p);
            p.setTextSize(10);p.setColor(0xff8aa0b5);
            if(!times.isEmpty()){
                String a=new java.text.SimpleDateFormat("HH:mm:ss",Locale.ENGLISH).format(new Date(times.get(0)));
                String b=new java.text.SimpleDateFormat("HH:mm:ss",Locale.ENGLISH).format(new Date(times.get(times.size()-1)));
                c.drawText(a,left,h-10,p);float tw=p.measureText(b);c.drawText(b,w-right-tw,h-10,p);
            }
        }
    }

    private void startNetworkClock(){
        if(clockExec!=null)return;
        clockExec=java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
        clockExec.scheduleAtFixedRate(()->{
            try{
                URL u=new URL("https://www.google.com/generate_204");
                HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setRequestMethod("HEAD"); c.setConnectTimeout(5000); c.setReadTimeout(5000);
                c.connect(); long ms=c.getHeaderFieldDate("Date",-1); c.disconnect();
                if(ms>0 && webView!=null)runOnUiThread(()->webView.evaluateJavascript("setNetworkTime("+ms+")",null));
            }catch(Exception ignored){}
        },0,30,java.util.concurrent.TimeUnit.SECONDS);
    }

    private void stopNetworkClock(){if(clockExec!=null){clockExec.shutdownNow();clockExec=null;}}

    private void showBot(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(22,8,22,4);
        TextView note=new TextView(this); note.setText("Online NSE Analyzer Bot\nIt can read a compact extract of the current analyzer screen. It must not invent missing market data."); note.setTextColor(0xff405060); box.addView(note);
        EditText key=edit("OpenAI API key (sk-...)",false); key.setTextColor(0xff202020); key.setHintTextColor(0xff607080); box.addView(key);
        EditText q=edit("Ask: entry / exit / OI / SL / target...",false); q.setTextColor(0xff202020); q.setHintTextColor(0xff607080); box.addView(q);
        TextView out=new TextView(this); out.setTextColor(0xff202020); out.setPadding(0,14,0,0); box.addView(out);
        Button ask=btn("Ask Bot"); box.addView(ask);
        AlertDialog d=new AlertDialog.Builder(this).setTitle("NSE AI Bot").setView(box).setNegativeButton("Close",null).create();
        ask.setOnClickListener(v->{String k=key.getText().toString().trim(), question=q.getText().toString().trim(); if(k.isEmpty()||question.isEmpty()){out.setText("Enter API key and question.");return;} out.setText("Analyzing…"); ask.setEnabled(false); webView.evaluateJavascript("document.body.innerText.substring(0,12000)", val->{String context=unquoteJs(val); new Thread(()->{String ans=callOpenAI(k,question,context); runOnUiThread(()->{out.setText(ans);ask.setEnabled(true);});}).start();});});
        d.show();
    }

    private String callOpenAI(String key,String question,String context){
        try{
            URL u=new URL("https://api.openai.com/v1/responses"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestProperty("Authorization","Bearer "+key); c.setRequestProperty("Content-Type","application/json");
            String instructions="You are the NSE Option Analyzer Bot. Analyze only the supplied screen context. Do not invent live price, OI, volume, support/resistance or trades. Treat the embedded V10 analyzer as the source of truth for its formulas. Explain observed facts separately from inference. Flow definitions: ΔOI>0 + premium>0 = Long Buildup; ΔOI<0 + premium>0 = Short Covering; ΔOI>0 + premium<0 = Short Buildup/Writing; ΔOI<0 + premium<0 = Long Unwinding. For BUY options verify SL < Entry < T1 < T2. If evidence conflicts, say WAIT/MIXED rather than forcing a trade. Perform arithmetic checks from the displayed numbers when asked: show the calculation steps, recompute differences/percentages/totals independently, compare your result with the displayed result, and clearly flag any mismatch. Never replace or modify the analyzer’s existing market formulas; treat them as read-only source logic.";
            JSONObject body=new JSONObject(); body.put("model","gpt-5.6-luna"); JSONArray input=new JSONArray(); JSONObject msg=new JSONObject(); msg.put("role","user"); msg.put("content",instructions+"\n\nUser question:\n"+question+"\n\nCurrent analyzer screen:\n"+context); input.put(msg); body.put("input",input);
            OutputStream os=c.getOutputStream(); os.write(body.toString().getBytes(StandardCharsets.UTF_8)); os.close(); int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String json=read(is); if(code<200||code>=300)return "API error "+code+": "+json; return extractOutputText(json);
        }catch(Exception e){return "Bot error: "+e.getMessage();}
    }
    private String extractOutputText(String json)throws Exception{ JSONObject o=new JSONObject(json); if(o.has("output_text"))return o.optString("output_text"); StringBuilder s=new StringBuilder(); JSONArray a=o.optJSONArray("output"); if(a!=null)for(int i=0;i<a.length();i++){JSONObject m=a.optJSONObject(i);JSONArray c=m==null?null:m.optJSONArray("content"); if(c!=null)for(int j=0;j<c.length();j++){JSONObject x=c.optJSONObject(j); if(x!=null&&"output_text".equals(x.optString("type")))s.append(x.optString("text"));}} return s.length()>0?s.toString():json; }
    private String read(InputStream is)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}
    private String unquoteJs(String s){ if(s==null)return ""; if(s.startsWith("\"")&&s.endsWith("\"")){try{return new org.json.JSONTokener(s).nextValue().toString();}catch(Exception ignored){}} return s; }
    private String sha256(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format("%02x",v));return x.toString();}catch(Exception e){return "";}}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_PICKER&&fileCallback!=null){Uri[] r=WebChromeClient.FileChooserParams.parseResult(resultCode,data);fileCallback.onReceiveValue(r);fileCallback=null;}}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){stopGroww(); stopNetworkClock(); if(webView!=null){webView.stopLoading();webView.destroy();}super.onDestroy();}
}

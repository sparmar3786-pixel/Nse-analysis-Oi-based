NSE Option Chain Analyzer V10 - Android App

This build keeps the V10 HTML analyzer as an unchanged asset and adds only an Android shell:
1) First launch: create a local app ID/password.
2) Later launches: login is required before the analyzer opens.
3) Internet permission is enabled for the existing live-data mode.
4) CSV/TSV/TXT file picker is retained.
5) An AI Bot button is added outside the analyzer. It can send a compact screen extract to the OpenAI Responses API using a user-supplied API key. No API key is embedded in the APK.

Important:
- The analyzer formulas/logic are not rewritten by the Android shell.
- Live NSE access may still be blocked by NSE/browser/CORS protections; the app must never fabricate live data.
- Do not hard-code an OpenAI API key into a distributed APK. The current bot asks for the key when used.
- For a production multi-user login, use a real authentication backend rather than local device-only credentials.

V13 visual/live-data upgrades:
- Professional sticky header with live IST date/time and Dark/Bright theme toggle.
- Network time is refreshed from an internet Date header when available; device time is shown as fallback.
- Uploaded CSV filenames are checked for detected snapshot date and clearly labeled current-date, back-date, or future-date data.
- Groww option-chain conversion corrected to the exact 23-column NSE grouped layout, including correct PE premium change sign.
- Groww exchange routing uses NSE for NIFTY/BANKNIFTY/etc. and BSE for SENSEX/BANKEX.
- Groww live price chart is improved with grid, min/max, current price and time range; it plots live underlying snapshots.

V15 indicator dashboard + validation fixes:
- EMA 8/13, EMA 20, SMA 50/200
- RSI 14, MACD 12/26/9, Stoch RSI, CCI 20, ROC 12
- ADX/+DI/-DI (close-series proxy when OHLC is unavailable)
- WaveTrend 10/21
- Bollinger Bands 20
- Option-chain PCR OI, PCR volume, Max Pain, average CE/PE IV
- Explicit unavailable state for OHLC-only indicators (Supertrend, Ichimoku, Parabolic SAR, ATR) instead of inventing OHLC data.
- Indicator timeframe selector and bullish/bearish/mixed consensus dashboard.
The core V10 setup/entry/SL/target engine is not rewritten by this dashboard.

V15 fixes after validation:
- Added crypto.randomUUID fallback for WebView/file/opaque-origin compatibility.
- Corrected PE-side flow-to-underlying mapping: PE Short Covering and Long Buildup are bearish; PE Short Buildup and Long Unwinding are bullish.
- PE setup eligibility now includes Short Covering as well as Long Buildup.
- Indicator dashboard EMA 8/13/20 now uses EMA rather than SMA.
- Backtest now prevents look-ahead bias by generating each signal only from snapshots available at that timestamp.
- Uploaded-file date check is now actually invoked. NSE filenames that contain only expiry date are not falsely treated as snapshot dates.
- Dashboard/market-state indicators refresh after data load.
- Expiry unknown is shown as — instead of NaN.

Validation performed on the included analyzer asset:
- JavaScript syntax check passed.
- Browser/WebView compatibility test passed after randomUUID fallback.
- All four OI classifications return correctly: LB, SC, SB, LU.
- PE mapping verified: LB/SC -> Bearish; SB/LU -> Bullish.
- Entry/SL/T1 invariants checked on parsed NIFTY data: SL < Entry < T1 and T1 remains within the configured 10–30 point minimum/maximum range; 0 violations in the tested plans.
- Current available historical files contained only 2 timestamped SENSEX snapshots; the NIFTY files had expiry-only filenames with no snapshot timestamp. Therefore the observed backtest is explicitly marked insufficient and is not presented as a reliable win-rate claim.


V16 professional UI layer:
- Refined typography, spacing, alignment, responsive grids, table readability, and dark/light color system.
- Improved Groww live chart presentation and live-snapshot labeling; existing 3-second live polling and Groww conversion logic are unchanged.
- AI Bot now explicitly performs visible arithmetic/calculation checks and reports calculation steps/mismatches while treating the analyzer market formulas as read-only.
- No existing share-market calculation formulas or setup/entry/SL/target logic were changed.

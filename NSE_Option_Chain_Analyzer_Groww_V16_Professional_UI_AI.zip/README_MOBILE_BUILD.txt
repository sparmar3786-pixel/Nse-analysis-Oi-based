MOBILE-ONLY APK BUILD
1. Create a GitHub repository from this folder.
2. Upload all files/folders, keeping the .github/workflows/build-apk.yml file.
3. Open Actions -> Build APK -> Run workflow.
4. Wait for the green check, then open the workflow run -> Artifacts -> NSE-Option-Chain-Analyzer-APK.
5. Download the ZIP, extract app-debug.apk, and install it on Android.


V10 update: index.html replaced with NSE_Option_Chain_Analyzer_V10.html. The original uploaded ZIP is unchanged.
